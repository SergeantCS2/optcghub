# OP TCG Hub — take 85

## If you are testing from Google Play — read this first

You got an **opt-in link**. Open it on your phone, tap *Become a tester*, then
install from the Play Store page it takes you to. Two things matter:

- **If you ever installed the app from an APK file** (not from Play): the Play
  version cannot install over it. In the APK app, **More → Export CSV** and
  send the file to yourself, then uninstall it, then install from Play and
  **More → Import** the CSV. Your collection comes back.
- **Stay installed for two weeks.** Google counts testers who keep the app;
  opting out or uninstalling resets that count for everyone.

Then, once: **More → Self-test → Run → Share the report** and send it to
the developer. It takes ten seconds and tells us your phone runs everything.

Updates arrive through Play like any app. Your data stays across updates.

---

**New at take 85:** prices can be shown in CAD, EUR, GBP, AUD, JPY, MXN or
CHF (More → Currency, or the currency pill on Home and Hunt) — converted
from the day's rates and marked ≈; and a brief opening screen.

**New at take 84:** nothing visible; the hourly stock workflow is fixed so
it can run.

**New at take 83:** pictures of every box, pack and deck in Hunt; the bottom
bar is the same size and colour in every mode and stands out more; screen
titles line up across modes; the Portfolio line reads as one piece; and the
back button can no longer leave a blank screen.

**New at take 82:** a hidden Diagnostics screen (tap the version line in
More five times) that writes a report you can send when something is wrong;
Prep & Play is charcoal and red now, so it no longer looks like Hunt; every
dropdown and text field matches the app; Releases rows link to full details.

**New at take 81:** first-impressions fixes from the Fold — typing a zip no
longer zooms the screen, the phone's back button goes back a page instead
of closing the app, reopening lands on the right screen, Hunt's search bar
and tab label are readable, and the Sealed list folds by set.

**New at take 80:** a visible focus ring for keyboard users on the web
version; nothing else changes.

**New at take 79:** distances in Hunt → Local and Events can be exact for
your zip with one tap (a one-time 200 KB download); until then they are
"about".

**New at take 78:** any event in Hunt → Events can go onto your phone's
calendar with one tap.

**New at take 77:** **stock alerts** — watch any box, pack or deck in Hunt
and get a notification the moment it turns up in stock at any source the app
tracks: Target online, a Target shelf near you, or a local shop's online
store.

**New at take 76:** Hunt → **Events** — every One Piece event near you for
the next month, with the fee, the date and the store, and a link to register
on Bandai TCG+. Hunt is green now.

**New at take 75:** local shops with an online store now show their sealed
One Piece stock and prices in Hunt, hourly — starting with the shops on a
verified list that grows as you add them.

**New at take 74:** Hunt → **Local** — every store that runs One Piece events
near your zip, with their next event dates, a distance filter, and your own
notes on what you saw on their shelves.

**New at take 73:** Hunt remembers stock over time — when a product was last
shipping and when each nearby store last had it on the shelf — so you can see
a store's restock pattern instead of guessing.

**New at take 72:** Hunt shows online prices and shipping stock for the whole
US, and asks for your zip once to add shelf stock at stores near you where
that area is covered.

**New at take 71:** Hunt → Sealed shows Target's price and which Target
stores near 48329 have it on the shelf, refreshed hourly. More stores and
shops follow.

**New at take 70:** a third mode, **Hunt** — every booster box, pack and
starter deck with its market price and nightly move, alerts on any of them,
and a release calendar. Local stores and store stock come next.

**New at take 69:** nothing visible; more of the sealed tracker's design.

**New at take 68:** nothing visible; the sealed-product tracker is designed.

**New at take 67:** nothing visible; a sealed-product price tracker and a
release calendar are planned as a third mode.

**New at take 66:** every button now has a name a screen reader can read,
and screen titles announce as headings instead of tabs. If you use TalkBack,
this is the update to try.

**New at take 65:** More has *Rate this app on Google Play* and *Tell someone
about the app*. No referral codes, no tracking in the link.

**New at take 64:** Overview and Performance are proper tabs now — tapping
one turns the other off, and Overview is tappable to come back.

**New at take 63:** the Decks tab is a card back instead of a crown, and the
skull on the empty collection screen is gone.

**New at take 62:** the ready-made decks have covers now — drawn by the app
from the Leader's colours and the set code, not downloaded from anywhere.

**New at take 61:** Decks now comes with 17 ready-made decks built from the
starter-deck sets, so you can try the Sim straight away without owning a
card. They are not in your collection and never count toward its value.

**New at take 60:** headings are gold again — they went pale in an earlier
update; small grey text is legible now rather than nearly invisible; and the
app no longer sprawls when you open it in a desktop browser.

**New at take 59:** nothing visible; an update can no longer shorten the
price history the nightly build has collected.

**New at take 58:** when a nightly build is missed, the app no longer calls
the price change "since yesterday" — it says the days it actually measured.
Two tests that had pinned themselves to particular prices are fixed.

**New at take 57:** nothing visible; two things you reported are on the
list for next time.

**New at take 56:** nothing visible; a test that expired on the third night
of prices is fixed, and this build carries that night's prices.

**New at take 55:** Sim can be played alone — choose *the app* as your
opponent. It plays by the rules and not at all cleverly; it never looks at
your hand. Good for trying decks and for finding effects that misfire.

**New at take 54:** nothing visible; a note in the protocol.

**New at take 53:** Home tells you what changed in each update; a deck's
screen says how much of it the Sim runs by itself and has a *Play this deck in
Sim* button; the board shows DON!! as pips and card colours as dots.

**New at take 52:** this guide, for Play testers; *Share the game log* in
Sim; the self-test checks the sim's effects too.

**New at take 51:** in Sim, searches work in every phrasing, granted
keywords (Rush, Blocker, Double Attack, Banish) count, and cost changes feed
the K.O. that follows. Over a quarter of all effect lines are scripted now.

**New at take 50:** in Sim, two-sentence effects run as two steps, and a
power change lasts exactly as long as the card says — this turn, or until
your next turn.

**New at take 49:** in Sim, Event cards work at both timings ([Main] from
hand, [Counter] in the counter step), and effects with a cost — trash a card,
return DON!!, rest this card — ask for the cost first. About one line in five
is scripted now; the rest is still yours to play by hand.

**New at take 48:** more cards offer their effects in Sim (about one line in
seven now), including searches, two-step effects and Trigger cards; the
defender sees the result of an attack before handing the phone back.

**New at take 47:** in Sim, some cards now offer their own effect at the
right moment (draw, rest, K.O., +power, DON!!) with the legal targets
listed; you Apply or Skip. Only effects the app fully understands are
offered — about one line in sixteen — the rest you play by hand as before.

**New at take 46:** Prep & Play → **Sim** — a two-player game on one phone.
Pick two legal decks, deal, and the app keeps the rules (phases, DON!!, cost,
attacks, block, counter, damage, Life); you play card effects by hand from
the ⋯ menu. Try one game with a friend and say what felt wrong.

**New at take 45:** More → **Self-test → Run** — the app checks itself on your
phone (catalogue, scanner gate, OCR, backup, camera, fonts, sync) and gives
you a report to paste. **Please run it once and send the report.**

**New at take 44:** Play → *Pass the phone* — one player's panel at a time,
and ending the turn drops a curtain naming who takes the phone next.

**New at take 42:** More → *Share as a web page* — your whole collection as
one page anyone can open, totals, set completion and all.

**New at take 41:** the app carries its own AdMob app ID; the ads you see are
still Google's test ads, on purpose.

**New at take 40:** nothing visible; ledgers only.

**New at take 39:** a showcase collection and deck to import (`showcase/`);
nothing you can see changes otherwise. Testers on the Play track: this is the
same app as the internal-test build, version code 39.

**New at take 35:** the shipped app carries no source comments (smaller,
cleaner); nothing you can see changes.

**New at take 34:** Export CSV opens the share sheet (it used to toast and
do nothing — landmine 110); Restore lets you pick a backup file.

**New at take 33:** the type — a poster face for headlines, comic lettering
on tabs, Open Sans for text, a heavy sans for the numbers; the compass icon is
back; the quiet price sync waits for wifi unless you say otherwise (More →
Sync); prices sync from the nightly build once you are online.

**Since take 22:** two modes (the slider at the top — Collect and Prep & Play,
the whole app changes face); a Life / DON!! counter for game day; a card
browse built for deck-building; set checklists with a want list; a binder view;
price alerts; portfolios; the Trade Analyzer; deck value and history; a
first-run tour; no more text prompts anywhere.

**Prices** refresh from the nightly build: quietly once per open on wifi, or
More → Sync now. If it says *Sync failed*, the Pages site is not up yet and
the app keeps the catalogue it came with.

**Ads** run against Google's test units. You start with 20 save credits and
1 deck save. Tap "+20 for a short ad" on Scan: watch it through and the count
rises; close it early and nothing happens. Both are correct.

## Five minutes, in order

0. **More → Self-test → Run** → share the report (once, first).
1. **Scan** two commons → the base printing is first → **Review →** → they are
   in Collection. Close the app fully, reopen: still there.
2. A **foil**, a **sleeved** card, a **toploader**. Found / read / right for
   each — this is the one unmeasured half of the scanner.
3. **Home → a set row** → the checklist → tap a missing card → it is on the
   want list (action row).
4. **Prep & Play → Decks → + New deck** → choose a Leader from the sheet →
   *Browse for this deck* → Blocker + a cost band → `+` a few → the count and
   the legality line move.
5. **Play** — set a Leader, tap Start, tap Next turn; the DON!! goes 1, 3, 5.
6. **Airplane mode, force-stop, reopen.** Everything above still works.
7. **Prep & Play → Sim** — with a friend and two decks, one phone: does the
   hand-over feel right, and did an effect ever fire when it shouldn't?

## Report

What you did, what you expected, what happened; a screenshot beats prose;
the exact text of any toast beats both.

---
Catalogue and prices: TCGplayer, via [TCGCSV](https://tcgcsv.com).
Not affiliated with Bandai, Shueisha, Toei Animation, Viz Media or TCGplayer.
Ads by Google AdMob.
